package com.redmagic.boost.ui

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButton
import com.redmagic.boost.R
import com.redmagic.boost.ShizukuHelper
import rikka.shizuku.Shizuku

class TurboFragment : Fragment() {

    private lateinit var tvShizukuStatus: TextView
    private lateinit var tvBoostLog: TextView
    private lateinit var btnConnectShizuku: MaterialButton
    private lateinit var btnTurboBoost: MaterialButton

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == 1001) {
            updateShizukuStatus()
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(requireContext(), "Shizuku conectado", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_turbo, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tvShizukuStatus = view.findViewById(R.id.tv_shizuku_status)
        tvBoostLog = view.findViewById(R.id.tv_boost_log)
        btnConnectShizuku = view.findViewById(R.id.btn_connect_shizuku)
        btnTurboBoost = view.findViewById(R.id.btn_turbo_boost)

        Shizuku.addRequestPermissionResultListener(permissionListener)
        updateShizukuStatus()

        btnConnectShizuku.setOnClickListener {
            requestShizukuPermission()
        }

        btnTurboBoost.setOnClickListener {
            executeTurboBoost()
        }
    }

    private fun updateShizukuStatus() {
        val connected = ShizukuHelper.hasPermission()
        if (connected) {
            tvShizukuStatus.text = "Estado Shizuku: Conectado"
            tvShizukuStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.accent_blue))
        } else {
            tvShizukuStatus.text = "Estado Shizuku: Desconectado"
            tvShizukuStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.accent_red))
        }
    }

    private fun requestShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                Toast.makeText(requireContext(), "Inicia el servicio de Shizuku primero", Toast.LENGTH_SHORT).show()
                return
            }
            if (ShizukuHelper.hasPermission()) {
                Toast.makeText(requireContext(), "Permiso ya concedido", Toast.LENGTH_SHORT).show()
            } else {
                Shizuku.requestPermission(1001)
            }
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Shizuku no está instalado o activo", Toast.LENGTH_SHORT).show()
        }
    }

    private fun executeTurboBoost() {
        val logBuilder = StringBuilder()

        // 1. Activar No Molestar (DND)
        val notificationManager = requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (notificationManager.isNotificationPolicyAccessGranted) {
            notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            logBuilder.append("• Modo No Molestar (DND) activado\n")
        } else {
            logBuilder.append("• DND requiere permiso (abriendo ajustes...)\n")
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }

        // 2. Limpieza de caché y optimización vía Shizuku
        if (ShizukuHelper.hasPermission()) {
            val trimOk = ShizukuHelper.runCommand("pm trim-caches 999999999999")
            val amOk = ShizukuHelper.runCommand("am kill-all")
            logBuilder.append(if (trimOk) "• Caché del sistema purgada\n" else "• Fallo al purgar caché\n")
            logBuilder.append(if (amOk) "• Procesos en segundo plano detenidos\n" else "• Fallo al detener procesos\n")
            logBuilder.append("• Turbo Boost completado al 100%")
        } else {
            logBuilder.append("• Conecta Shizuku para limpieza profunda de caché y RAM")
        }

        tvBoostLog.text = logBuilder.toString()
        Toast.makeText(requireContext(), "Turbo Boost ejecutado", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Shizuku.removeRequestPermissionResultListener(permissionListener)
    }
}
