package com.redmagic.boost.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.materialswitch.MaterialSwitch
import com.redmagic.boost.DevilService
import com.redmagic.boost.R
import com.redmagic.boost.ShizukuHelper

class SettingsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val switchDevil = view.findViewById<MaterialSwitch>(R.id.switch_devil_mode)
        val tvDevilStatus = view.findViewById<TextView>(R.id.tv_devil_status)
        val tvVersion = view.findViewById<TextView>(R.id.tv_app_version)

        tvVersion.text = "RedMagicBoost v2.0 (Build 2)"

        val prefs = requireContext().getSharedPreferences("settings_prefs", Context.MODE_PRIVATE)
        val isDevilActive = prefs.getBoolean("devil_mode_enabled", false)
        switchDevil.isChecked = isDevilActive
        updateStatusText(tvDevilStatus, isDevilActive)

        switchDevil.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (!ShizukuHelper.hasPermission()) {
                    switchDevil.isChecked = false
                    Toast.makeText(requireContext(), "Requiere conexión con Shizuku", Toast.LENGTH_SHORT).show()
                    return@setOnCheckedChangeListener
                }
                val intent = Intent(requireContext(), DevilService::class.java)
                ContextCompat.startForegroundService(requireContext(), intent)
                prefs.edit().putBoolean("devil_mode_enabled", true).apply()
                updateStatusText(tvDevilStatus, true)
                Toast.makeText(requireContext(), "Modo Diablo activado (2.2GHz)", Toast.LENGTH_SHORT).show()
            } else {
                requireContext().stopService(Intent(requireContext(), DevilService::class.java))
                prefs.edit().putBoolean("devil_mode_enabled", false).apply()
                updateStatusText(tvDevilStatus, false)
                Toast.makeText(requireContext(), "Modo Diablo desactivado", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateStatusText(textView: TextView, active: Boolean) {
        if (active) {
            textView.text = "Bucle 2.2GHz: ACTIVO"
            textView.setTextColor(ContextCompat.getColor(requireContext(), R.color.accent_red))
        } else {
            textView.text = "Bucle 2.2GHz: INACTIVO"
            textView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary))
        }
    }
}
