package com.redmagic.boost.ui

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch
import com.redmagic.boost.R

data class AppItem(
    val name: String,
    val packageName: String,
    val icon: Drawable,
    var isBoosted: Boolean
)

class GamesAdapter(
    private val items: List<AppItem>,
    private val onToggleChanged: (AppItem, Boolean) -> Unit
) : RecyclerView.Adapter<GamesAdapter.GameViewHolder>() {

    class GameViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val ivIcon: ImageView = view.findViewById(R.id.iv_app_icon)
        val tvName: TextView = view.findViewById(R.id.tv_app_name)
        val tvPackage: TextView = view.findViewById(R.id.tv_app_package)
        val switchTurbo: MaterialSwitch = view.findViewById(R.id.switch_game_turbo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GameViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_game, parent, false)
        return GameViewHolder(view)
    }

    override fun onBindViewHolder(holder: GameViewHolder, position: Int) {
        val item = items[position]
        holder.ivIcon.setImageDrawable(item.icon)
        holder.tvName.text = item.name
        holder.tvPackage.text = item.packageName

        holder.switchTurbo.setOnCheckedChangeListener(null)
        holder.switchTurbo.isChecked = item.isBoosted

        holder.switchTurbo.setOnCheckedChangeListener { _, isChecked ->
            item.isBoosted = isChecked
            onToggleChanged(item, isChecked)
        }
    }

    override fun getItemCount(): Int = items.size
}
