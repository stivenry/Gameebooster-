package com.redmagic.boost.ui

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.redmagic.boost.R

class GamesFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var tvGamesCount: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_games, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.rv_games)
        tvGamesCount = view.findViewById(R.id.tv_games_count)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        loadInstalledApps()
    }

    private fun loadInstalledApps() {
        val pm = requireContext().packageManager
        val prefs = requireContext().getSharedPreferences("game_turbo_prefs", Context.MODE_PRIVATE)
        val savedPackages = prefs.getStringSet("boosted_apps", emptySet()) ?: emptySet()

        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val userApps = packages.filter { appInfo ->
            (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
                    appInfo.packageName != requireContext().packageName
        }.map { appInfo ->
            AppItem(
                name = appInfo.loadLabel(pm).toString(),
                packageName = appInfo.packageName,
                icon = appInfo.loadIcon(pm),
                isBoosted = savedPackages.contains(appInfo.packageName)
            )
        }.sortedBy { it.name.lowercase() }

        tvGamesCount.text = "${userApps.size} aplicaciones detectadas"

        recyclerView.adapter = GamesAdapter(userApps) { appItem, isChecked ->
            val currentSet = prefs.getStringSet("boosted_apps", emptySet())?.toMutableSet() ?: mutableSetOf()
            if (isChecked) {
                currentSet.add(appItem.packageName)
            } else {
                currentSet.remove(appItem.packageName)
            }
            prefs.edit().putStringSet("boosted_apps", currentSet).apply()
        }
    }
}
