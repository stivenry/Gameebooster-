# RedMagicBoost v5.0

Game Turbo para Poco X3 NFC (Android 12) sin root, usando Shizuku.

## Compilar con GitHub Actions
1. Crea un repositorio y sube TODO el contenido de este ZIP (carpeta `app/`, `.github/`, archivos `.kts` y `gradle.properties`).
2. Ve a Actions > "Build Android APK" > Run workflow.
3. Descarga el artefacto `RedMagicBoost-v5-apk` (contiene `app-debug.apk`).

## Uso
1. Instala Shizuku y arrancalo por Depuracion inalambrica.
2. Abre RedMagicBoost > Turbo > "Conectar Shizuku" y acepta el permiso.
3. Turbo > "Mostrar menu flotante" (te pedira el permiso de superposicion).
4. Juegos: toca un juego para abrir sus Ajustes por Juego; activa el switch para que se le aplique el perfil al abrirlo (con el menu flotante activo).
5. Log de telemetria: Android/data/com.redmagic.boost/files/redmagic_log.txt

## Importante
Sin root, algunos ajustes dependen del kernel/ROM y pueden fallar. La app lo indica en cada log
y revierte el switch si el comando no se ejecuto.
