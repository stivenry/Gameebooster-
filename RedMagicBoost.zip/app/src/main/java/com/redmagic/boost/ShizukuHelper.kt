package com.redmagic.boost
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
object ShizukuHelper {
    fun hasPermission(): Boolean {
        return try {
            if (Shizuku.isPreV11() || Shizuku.getVersion() < 11) return false
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) { false }
    }
    fun runCommand(command: String): Boolean {
        if (!hasPermission()) return false
        return try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            process.waitFor()
        } catch (e: Exception) { false }
    }
}
