package com.redmagic.boost

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings

data class Tweak(
    val key: String,
    val group: String,
    val title: String,
    val desc: String,
    val enable: (Context) -> Boolean,
    val disable: (Context) -> Boolean
)

/**
 * Catalogo de ajustes inspirados en Xiaomi Game Turbo, RedMagic Game Space e
 * Infinix XBoost / Game Mode. Todos se ejecutan como shell (Shizuku), sin root.
 * Si el comando no existe en tu ROM, el switch se revierte solo.
 */
object TweakCatalog {

    const val G_XIAOMI = "Estilo Xiaomi Game Turbo"
    const val G_REDMAGIC = "Estilo RedMagic Game Space"
    const val G_INFINIX = "Estilo Infinix XBoost"
    const val G_SISTEMA = "Sistema y red"

    private fun sh(vararg cmds: String): (Context) -> Boolean = { _ ->
        var any = false
        for (c in cmds) {
            if (ShizukuHelper.runCommand(c)) any = true
        }
        any
    }

    val all: List<Tweak> = listOf(
        // ---------------- Xiaomi Game Turbo ----------------
        Tweak(
            "thermal", G_XIAOMI, "Thermal Override",
            "Detiene com.xiaomi.joyose (gestor termico de MIUI) y fuerza estado termico 0. Vigila la temperatura en el HUD.",
            sh(
                "am force-stop com.xiaomi.joyose",
                "pm disable-user --user 0 com.xiaomi.joyose",
                "cmd thermalservice override-status 0"
            ),
            sh(
                "pm enable com.xiaomi.joyose",
                "cmd thermalservice reset"
            )
        ),
        Tweak(
            "perfmode", G_XIAOMI, "Modo rendimiento fijo",
            "Activa el modo de rendimiento fijo del servicio de energia de Android.",
            sh("cmd power set-fixed-performance-mode-enabled true"),
            sh("cmd power set-fixed-performance-mode-enabled false")
        ),
        Tweak(
            "dnd", G_XIAOMI, "No molestar (solo prioridad)",
            "Silencia llamadas y notificaciones mientras juegas.",
            sh("cmd notification set_dnd priority"),
            sh("cmd notification set_dnd off")
        ),
        Tweak(
            "headsup", G_XIAOMI, "Bloquear notificaciones emergentes",
            "Desactiva los avisos flotantes que tapan la pantalla.",
            sh("settings put global heads_up_notifications_enabled 0"),
            sh("settings put global heads_up_notifications_enabled 1")
        ),
        Tweak(
            "gestures", G_XIAOMI, "Anular gestos de borde",
            "Pone a 0 la zona del gesto Atras para evitar salidas accidentales del juego.",
            sh(
                "settings put secure back_gesture_inset_scale_left 0",
                "settings put secure back_gesture_inset_scale_right 0"
            ),
            sh(
                "settings delete secure back_gesture_inset_scale_left",
                "settings delete secure back_gesture_inset_scale_right"
            )
        ),
        Tweak(
            "brightness", G_XIAOMI, "Brillo manual fijo",
            "Desactiva el brillo automatico para que no cambie en plena partida.",
            sh("settings put system screen_brightness_mode 0"),
            sh("settings put system screen_brightness_mode 1")
        ),
        Tweak(
            "stayawake", G_XIAOMI, "Pantalla encendida al cargar",
            "Mantiene la pantalla encendida mientras el cargador esta conectado.",
            sh("settings put global stay_on_while_plugged_in 7"),
            sh("settings put global stay_on_while_plugged_in 0")
        ),
        Tweak(
            "wifilat", G_XIAOMI, "Wi-Fi baja latencia",
            "Pide al Wi-Fi modo de baja latencia y alto rendimiento.",
            sh(
                "cmd wifi force-low-latency-mode enabled",
                "cmd wifi force-hi-perf-mode enabled"
            ),
            sh(
                "cmd wifi force-low-latency-mode disabled",
                "cmd wifi force-hi-perf-mode disabled"
            )
        ),

        // ---------------- RedMagic Game Space ----------------
        Tweak(
            "refresh120", G_REDMAGIC, "Forzar 120 Hz",
            "Fija la tasa de refresco minima y maxima en 120 Hz.",
            sh(
                "settings put system peak_refresh_rate 120.0",
                "settings put system min_refresh_rate 120.0",
                "settings put system user_refresh_rate 120"
            ),
            sh(
                "settings delete system min_refresh_rate",
                "settings delete system user_refresh_rate"
            )
        ),
        Tweak(
            "anim", G_REDMAGIC, "Animaciones del sistema desactivadas",
            "Quita las animaciones de ventana y transicion para una respuesta mas rapida.",
            sh(
                "settings put global window_animation_scale 0",
                "settings put global transition_animation_scale 0",
                "settings put global animator_duration_scale 0"
            ),
            sh(
                "settings put global window_animation_scale 1",
                "settings put global transition_animation_scale 1",
                "settings put global animator_duration_scale 1"
            )
        ),
        Tweak(
            "lowpower", G_REDMAGIC, "Ahorro de bateria desactivado",
            "Apaga el ahorro de bateria y el ahorro adaptativo para no limitar el rendimiento.",
            sh(
                "settings put global low_power 0",
                "settings put global adaptive_battery_management_enabled 0"
            ),
            sh("settings put global adaptive_battery_management_enabled 1")
        ),
        Tweak(
            "phantom", G_REDMAGIC, "Desactivar Phantom Process Killer",
            "Evita que Android mate procesos secundarios de apps y juegos.",
            sh(
                "device_config set_sync_disabled_for_tests persistent",
                "device_config put activity_manager max_phantom_processes 2147483647",
                "settings put global settings_enable_monitor_phantom_procs false"
            ),
            sh(
                "device_config put activity_manager max_phantom_processes 32",
                "device_config set_sync_disabled_for_tests none",
                "settings put global settings_enable_monitor_phantom_procs true"
            )
        ),

        // ---------------- Infinix XBoost ----------------
        Tweak(
            "freeze", G_INFINIX, "Congelacion de apps",
            "Detiene y restringe en segundo plano las apps de terceros (excepto juegos marcados, launcher, teclado y Shizuku).",
            { ctx -> freezeApps(ctx, true) },
            { ctx -> freezeApps(ctx, false) }
        ),
        Tweak(
            "cachedprocs", G_INFINIX, "Limitar procesos en cache",
            "Reduce a 8 los procesos que Android mantiene en cache para liberar RAM.",
            sh("settings put global activity_manager_constants max_cached_processes=8"),
            sh("settings delete global activity_manager_constants")
        ),
        Tweak(
            "scans", G_INFINIX, "Apagar escaneos Wi-Fi/Bluetooth en segundo plano",
            "Evita escaneos constantes que consumen CPU y generan lag de red.",
            sh(
                "settings put global wifi_scan_always_enabled 0",
                "settings put global ble_scan_always_enabled 0"
            ),
            sh(
                "settings put global wifi_scan_always_enabled 1",
                "settings put global ble_scan_always_enabled 1"
            )
        ),

        // ---------------- Sistema y red ----------------
        Tweak(
            "netprio", G_SISTEMA, "Prioridad de red",
            "Restringe datos en segundo plano y pide Wi-Fi de alto rendimiento. La regla iptables (DSCP) solo funciona con root; sin root se ignora.",
            { _ -> netPriority(true) },
            { _ -> netPriority(false) }
        ),
        Tweak(
            "dns", G_SISTEMA, "DNS privado (Cloudflare)",
            "Usa 1dot1dot1dot1.cloudflare-dns.com como DNS privado para menor latencia.",
            sh(
                "settings put global private_dns_mode hostname",
                "settings put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com"
            ),
            sh("settings put global private_dns_mode opportunistic")
        )
    )

    private fun netPriority(enable: Boolean): Boolean {
        val cmds = if (enable) {
            listOf(
                "cmd netpolicy set restrict-background true",
                "cmd wifi force-hi-perf-mode enabled",
                "iptables -t mangle -A OUTPUT -j DSCP --set-dscp 46"
            )
        } else {
            listOf(
                "cmd netpolicy set restrict-background false",
                "cmd wifi force-hi-perf-mode disabled",
                "iptables -t mangle -D OUTPUT -j DSCP --set-dscp 46"
            )
        }
        var any = false
        for (c in cmds) {
            if (ShizukuHelper.runCommand(c)) any = true
        }
        return any
    }

    private fun protectedPackages(ctx: Context): Set<String> {
        val keep = mutableSetOf(ctx.packageName, "moe.shizuku.privileged.api")
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val launcher = ctx.packageManager
            .resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        if (launcher != null) keep.add(launcher)
        val ime = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        if (ime != null) keep.add(ime.substringBefore("/"))
        val prefs = ctx.getSharedPreferences("game_turbo_prefs", Context.MODE_PRIVATE)
        keep.addAll(prefs.getStringSet("boosted_apps", emptySet()) ?: emptySet())
        return keep
    }

    private fun freezeApps(ctx: Context, enable: Boolean): Boolean {
        val keep = protectedPackages(ctx)
        val pkgs = ShizukuShell.out("pm list packages -3").lines()
            .map { it.trim().removePrefix("package:") }
            .filter { it.isNotEmpty() && (!enable || it !in keep) }
        if (pkgs.isEmpty()) return false
        val script = pkgs.joinToString("; ") { p ->
            if (enable) {
                "am force-stop $p; cmd appops set $p RUN_ANY_IN_BACKGROUND ignore; am set-standby-bucket $p restricted"
            } else {
                "cmd appops set $p RUN_ANY_IN_BACKGROUND allow; am set-standby-bucket $p active"
            }
        }
        return ShizukuHelper.runCommand(script)
    }
}
