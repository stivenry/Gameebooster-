package com.redmagic.boost

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Menu flotante: boton arrastrable que abre un panel con HUD en vivo,
 * Turbo Boost, Modo Diablo, captura, grabacion y crosshair configurable.
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var themed: Context
    private var bubble: View? = null
    private var panel: View? = null
    private var crosshair: CrosshairView? = null
    private var tvBubble: TextView? = null
    private var tvHud: TextView? = null
    private var monitor: LogMonitor? = null
    private var recording = false

    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private val colors = intArrayOf(
        Color.parseColor("#E25C5C"),
        Color.parseColor("#4CFF4C"),
        Color.parseColor("#00E5FF"),
        Color.WHITE,
        Color.parseColor("#FFEB3B")
    )
    private val styleNames = arrayOf("Cruz", "Punto", "Circulo")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        themed = ContextThemeWrapper(this, R.style.Theme_RedMagicBoost)
        getSharedPreferences("overlay_prefs", MODE_PRIVATE).edit().putBoolean("running", true).apply()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (bubble == null) {
            createCrosshair()
            createPanel()
            createBubble()
            startMonitor()
        }
        return START_STICKY
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun startAsForeground() {
        val ch = NotificationChannel("overlay_channel", "Menu flotante", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
        val n: Notification = NotificationCompat.Builder(this, "overlay_channel")
            .setContentTitle("RedMagicBoost")
            .setContentText("Menu flotante y telemetria activos")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
        startForeground(102, n)
    }

    private fun createCrosshair() {
        val prefs = getSharedPreferences("overlay_prefs", MODE_PRIVATE)
        val v = CrosshairView(this)
        v.sizeDp = prefs.getInt("ch_size", 30)
        v.color = colors[prefs.getInt("ch_color", 0) % colors.size]
        v.style = prefs.getInt("ch_style", 0)
        v.visibility = if (prefs.getBoolean("ch_on", false)) View.VISIBLE else View.GONE
        val lp = WindowManager.LayoutParams(
            dp(200), dp(200), overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER
        wm.addView(v, lp)
        crosshair = v
    }

    private fun createPanel() {
        val prefs = getSharedPreferences("overlay_prefs", MODE_PRIVATE)
        val v = LayoutInflater.from(themed).inflate(R.layout.overlay_panel, null)
        tvHud = v.findViewById<TextView>(R.id.tv_hud)

        v.findViewById<MaterialButton>(R.id.btn_p_turbo).setOnClickListener {
            toast("Ejecutando Turbo Boost...")
            worker.execute {
                val lines = TurboActions.boost(applicationContext)
                main.post { toast(lines.last()) }
            }
        }

        val devilBtn = v.findViewById<MaterialButton>(R.id.btn_p_devil)
        val settingsPrefs = getSharedPreferences("settings_prefs", MODE_PRIVATE)
        devilBtn.text = if (settingsPrefs.getBoolean("devil_mode_enabled", false)) "Diablo: ON" else "Modo Diablo"
        devilBtn.setOnClickListener {
            val on = settingsPrefs.getBoolean("devil_mode_enabled", false)
            if (!on) {
                if (!ShizukuHelper.hasPermission()) {
                    toast("Requiere conexion con Shizuku")
                } else {
                    ContextCompat.startForegroundService(this, Intent(this, DevilService::class.java))
                    settingsPrefs.edit().putBoolean("devil_mode_enabled", true).apply()
                    devilBtn.text = "Diablo: ON"
                }
            } else {
                stopService(Intent(this, DevilService::class.java))
                settingsPrefs.edit().putBoolean("devil_mode_enabled", false).apply()
                devilBtn.text = "Modo Diablo"
            }
        }

        v.findViewById<MaterialButton>(R.id.btn_p_shot).setOnClickListener {
            panel?.visibility = View.GONE
            worker.execute {
                try {
                    Thread.sleep(500)
                } catch (e: InterruptedException) {
                    // ignorado
                }
                val file = "/sdcard/Pictures/RedMagic_" + stamp() + ".png"
                val ok = ShizukuHelper.runCommand("mkdir -p /sdcard/Pictures; screencap -p " + file)
                main.post {
                    panel?.visibility = View.VISIBLE
                    toast(if (ok) "Captura guardada en Pictures" else "No se pudo capturar")
                }
            }
        }

        val recBtn = v.findViewById<MaterialButton>(R.id.btn_p_rec)
        recBtn.setOnClickListener {
            if (!recording) {
                if (!ShizukuHelper.hasPermission()) {
                    toast("Requiere conexion con Shizuku")
                } else {
                    recording = true
                    recBtn.text = "Detener"
                    Thread {
                        ShizukuHelper.runCommand(
                            "mkdir -p /sdcard/Movies; screenrecord --time-limit 180 /sdcard/Movies/RedMagic_" + stamp() + ".mp4"
                        )
                        main.post {
                            recording = false
                            recBtn.text = "Grabar"
                            toast("Grabacion finalizada (carpeta Movies)")
                        }
                    }.start()
                }
            } else {
                Thread { ShizukuHelper.runCommand("pkill -2 screenrecord") }.start()
            }
        }

        // Crosshair
        val sw = v.findViewById<MaterialSwitch>(R.id.sw_crosshair)
        val sb = v.findViewById<SeekBar>(R.id.sb_ch_size)
        val btnColor = v.findViewById<MaterialButton>(R.id.btn_ch_color)
        val btnStyle = v.findViewById<MaterialButton>(R.id.btn_ch_style)
        sw.isChecked = prefs.getBoolean("ch_on", false)
        sb.max = 70
        sb.progress = prefs.getInt("ch_size", 30) - 10
        btnStyle.text = styleNames[prefs.getInt("ch_style", 0) % styleNames.size]
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("ch_on", on).apply()
            crosshair?.visibility = if (on) View.VISIBLE else View.GONE
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val size = 10 + progress
                prefs.edit().putInt("ch_size", size).apply()
                crosshair?.sizeDp = size
                crosshair?.invalidate()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        btnColor.setOnClickListener {
            val i = (prefs.getInt("ch_color", 0) + 1) % colors.size
            prefs.edit().putInt("ch_color", i).apply()
            crosshair?.color = colors[i]
            crosshair?.invalidate()
        }
        btnStyle.setOnClickListener {
            val i = (prefs.getInt("ch_style", 0) + 1) % styleNames.size
            prefs.edit().putInt("ch_style", i).apply()
            crosshair?.style = i
            crosshair?.invalidate()
            btnStyle.text = styleNames[i]
        }

        v.findViewById<MaterialButton>(R.id.btn_p_close).setOnClickListener { stopSelf() }

        val lp = WindowManager.LayoutParams(
            dp(300), WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dp(90)
        v.visibility = View.GONE
        wm.addView(v, lp)
        panel = v
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createBubble() {
        val v = LayoutInflater.from(themed).inflate(R.layout.overlay_bubble, null)
        tvBubble = v.findViewById<TextView>(R.id.tv_bubble)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(12)
        lp.y = dp(160)
        v.setOnTouchListener(DragListener(lp, v))
        wm.addView(v, lp)
        bubble = v
    }

    private inner class DragListener(
        private val lp: WindowManager.LayoutParams,
        private val target: View
    ) : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    lp.x = startX + dx
                    lp.y = startY + dy
                    wm.updateViewLayout(target, lp)
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    return true
                }
            }
            return false
        }
    }

    private fun togglePanel() {
        val p = panel ?: return
        p.visibility = if (p.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun startMonitor() {
        monitor = LogMonitor(applicationContext) { t ->
            val fpsTxt = if (t.fps >= 0) t.fps.toString() else "--"
            val temp = String.format(Locale.US, "%.1f", t.tempC)
            val game = if (t.pkg.isNotEmpty()) "\n" + t.pkg else ""
            tvHud?.text = "FPS: " + fpsTxt + "   CPU: " + t.cpuMhz + " MHz\n" +
                    "TEMP: " + temp + " C   RAM: " + t.ramUsedPct + "%" + game
            tvBubble?.text = if (t.fps >= 0) fpsTxt else "RM"
        }
        monitor?.start()
    }

    override fun onDestroy() {
        monitor?.stop()
        for (v in listOf(bubble, panel, crosshair)) {
            try {
                if (v != null) wm.removeView(v)
            } catch (e: Exception) {
                // vista ya removida
            }
        }
        worker.shutdownNow()
        getSharedPreferences("overlay_prefs", MODE_PRIVATE).edit().putBoolean("running", false).apply()
        super.onDestroy()
    }
}
