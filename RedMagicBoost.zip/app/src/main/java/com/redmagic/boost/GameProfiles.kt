package com.redmagic.boost

import android.content.Context
import java.util.Locale
import kotlin.math.abs

/**
 * Perfil por juego: tactil, bordes, muestreo, resolucion/densidad y modo de juego.
 */
object GameProfiles {

    private const val PREFS = "game_profiles"

    data class Profile(
        var sens: Int = 50,
        var edge: Int = 0,
        var touchBoost: Boolean = false,
        var resPercent: Int = 100,
        var density: Int = 0,
        var perfMode: Boolean = true,
        var compile: Boolean = false
    )

    fun hasProfile(ctx: Context, pkg: String): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(pkg + ".sens")

    fun load(ctx: Context, pkg: String): Profile {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Profile(
            sens = p.getInt(pkg + ".sens", 50),
            edge = p.getInt(pkg + ".edge", 0),
            touchBoost = p.getBoolean(pkg + ".boost", false),
            resPercent = p.getInt(pkg + ".res", 100),
            density = p.getInt(pkg + ".dens", 0),
            perfMode = p.getBoolean(pkg + ".perf", true),
            compile = p.getBoolean(pkg + ".compile", false)
        )
    }

    fun save(ctx: Context, pkg: String, pr: Profile) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(pkg + ".sens", pr.sens)
            .putInt(pkg + ".edge", pr.edge)
            .putBoolean(pkg + ".boost", pr.touchBoost)
            .putInt(pkg + ".res", pr.resPercent)
            .putInt(pkg + ".dens", pr.density)
            .putBoolean(pkg + ".perf", pr.perfMode)
            .putBoolean(pkg + ".compile", pr.compile)
            .apply()
    }

    private fun physicalSize(): Pair<Int, Int> {
        val out = ShizukuShell.out("wm size")
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(out)
        return if (m != null) {
            Pair(m.groupValues[1].toInt(), m.groupValues[2].toInt())
        } else {
            Pair(1080, 2400)
        }
    }

    private fun physicalDensity(): Int {
        val out = ShizukuShell.out("wm density")
        val m = Regex("Physical density: (\\d+)").find(out)
        return if (m != null) m.groupValues[1].toInt() else 440
    }

    /** Bloqueante: llamar siempre desde un hilo secundario. */
    fun apply(ctx: Context, pkg: String, pr: Profile): List<String> {
        val log = mutableListOf<String>()
        if (!ShizukuHelper.hasPermission()) {
            log.add("• Conecta Shizuku primero (pestana Turbo)")
            return log
        }

        // Tactil: tiempo de pulsacion larga y velocidad de puntero segun sensibilidad
        val longPress = 500 - pr.sens * 3
        val speed = ((pr.sens - 50) / 50.0 * 7).toInt()
        val okTouch = ShizukuHelper.runCommand(
            "settings put secure long_press_timeout " + longPress +
                    "; settings put system pointer_speed " + speed
        )
        log.add(if (okTouch) "• Sensibilidad tactil aplicada (" + pr.sens + "%)" else "• Sensibilidad tactil: fallo")

        // Supresion de bordes: reduce la zona del gesto Atras
        val scale = String.format(Locale.US, "%.2f", (100 - pr.edge) / 100.0)
        val okEdge = ShizukuHelper.runCommand(
            "settings put secure back_gesture_inset_scale_left " + scale +
                    "; settings put secure back_gesture_inset_scale_right " + scale
        )
        log.add(if (okEdge) "• Supresion de bordes " + pr.edge + "%" else "• Supresion de bordes: fallo")

        // Muestreo tactil (depende del kernel, normalmente requiere root)
        if (pr.touchBoost) {
            val ok = ShizukuHelper.runCommand("echo 1 > /sys/class/touch/touch_dev/polling_rate")
            log.add(if (ok) "• Muestreo tactil alto activado" else "• Muestreo tactil: no soportado en este kernel sin root")
        }

        // Resolucion y densidad
        val size = physicalSize()
        if (pr.resPercent < 100) {
            val nw = (size.first * pr.resPercent / 100) / 2 * 2
            val nh = (size.second * pr.resPercent / 100) / 2 * 2
            val ok = ShizukuHelper.runCommand("wm size " + nw + "x" + nh)
            log.add(if (ok) "• Resolucion " + nw + "x" + nh else "• Resolucion: fallo")
        } else {
            ShizukuHelper.runCommand("wm size reset")
        }
        val physD = physicalDensity()
        if (pr.density > 0 && abs(pr.density - physD) >= 10) {
            val ok = ShizukuHelper.runCommand("wm density " + pr.density)
            log.add(if (ok) "• Densidad " + pr.density + " dpi" else "• Densidad: fallo")
        } else {
            ShizukuHelper.runCommand("wm density reset")
        }

        // Modo de juego Android
        if (pr.perfMode) {
            val ok = ShizukuHelper.runCommand(
                "cmd game mode performance " + pkg + " || cmd game set --mode 2 " + pkg
            )
            log.add(if (ok) "• Modo de juego: rendimiento" else "• Modo de juego: no disponible")
        }

        // Compilacion AOT
        if (pr.compile) {
            val ok = ShizukuHelper.runCommand("cmd package compile -m speed -f " + pkg)
            log.add(if (ok) "• Juego compilado en modo speed" else "• Compilacion: fallo")
        }
        return log
    }

    /** Restaura tactil, bordes, resolucion y densidad. Bloqueante. */
    fun restore(ctx: Context): List<String> {
        val log = mutableListOf<String>()
        if (!ShizukuHelper.hasPermission()) {
            log.add("• Conecta Shizuku primero")
            return log
        }
        val ok = ShizukuHelper.runCommand(
            "wm size reset; wm density reset" +
                    "; settings delete secure back_gesture_inset_scale_left" +
                    "; settings delete secure back_gesture_inset_scale_right" +
                    "; settings put secure long_press_timeout 400" +
                    "; settings put system pointer_speed 0"
        )
        log.add(if (ok) "• Valores originales restaurados" else "• No se pudo restaurar todo")
        return log
    }
}
