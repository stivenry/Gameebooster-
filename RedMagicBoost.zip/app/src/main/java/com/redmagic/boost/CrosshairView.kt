package com.redmagic.boost

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** Mira virtual dibujada en el centro de la pantalla. style: 0 cruz, 1 punto, 2 circulo. */
class CrosshairView(context: Context) : View(context) {

    var sizeDp: Int = 30
    var color: Int = Color.RED
    var style: Int = 0

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val r = sizeDp * d / 2f
        paint.color = color
        paint.strokeWidth = 2f * d
        when (style) {
            1 -> {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, maxOf(r * 0.25f, 3f * d), paint)
            }
            2 -> {
                paint.style = Paint.Style.STROKE
                canvas.drawCircle(cx, cy, r, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, 2f * d, paint)
            }
            else -> {
                paint.style = Paint.Style.STROKE
                val gap = r * 0.25f
                canvas.drawLine(cx - r, cy, cx - gap, cy, paint)
                canvas.drawLine(cx + gap, cy, cx + r, cy, paint)
                canvas.drawLine(cx, cy - r, cx, cy - gap, paint)
                canvas.drawLine(cx, cy + gap, cx, cy + r, paint)
            }
        }
    }
}
