package com.redmagic.boost

import android.app.ActivityManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Hilo de telemetria: cada 2 segundos lee frecuencia de CPU (via Shizuku),
 * FPS (dumpsys SurfaceFlinger), temperatura y RAM. Entrega los datos al HUD y
 * los guarda en redmagic_log.txt (Android/data/com.redmagic.boost/files/).
 * Ademas aplica el perfil por juego cuando detecta un juego marcado en primer plano.
 */
class LogMonitor(
    private val context: Context,
    private val onUpdate: (Telemetry) -> Unit
) {

    data class Telemetry(
        val fps: Int,
        val cpuMhz: Int,
        val tempC: Float,
        val ramUsedPct: Int,
        val pkg: String
    )

    @Volatile
    private var running = false
    private var thread: Thread? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var activeGame = ""
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    fun start() {
        if (running) return
        running = true
        thread = Thread { loop() }.apply {
            isDaemon = true
            start()
        }
    }

    fun stop() {
        running = false
        thread?.interrupt()
    }

    private fun loop() {
        while (running) {
            try {
                val t = sample()
                appendLog(t)
                mainHandler.post { onUpdate(t) }
                autoProfile(t.pkg)
            } catch (e: Exception) {
                // un fallo de lectura no debe matar el hilo
            }
            try {
                Thread.sleep(2000)
            } catch (e: InterruptedException) {
                break
            }
        }
    }

    private fun sample(): Telemetry {
        val pkg = foregroundPackage()
        val cpu = readCpuMhz()
        val temp = readTemp()
        val ram = readRamPct()
        val fps = if (pkg.isNotEmpty()) readFps(pkg) else -1
        return Telemetry(fps, cpu, temp, ram, pkg)
    }

    private fun foregroundPackage(): String {
        val out = ShizukuShell.out("dumpsys window | grep mCurrentFocus")
        val m = Regex("mCurrentFocus=Window\\{\\S+ \\S+ ([\\w.]+)/").find(out)
        return if (m != null) m.groupValues[1] else ""
    }

    private fun readCpuMhz(): Int {
        val out = ShizukuShell.out("cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq")
        val max = out.lines().mapNotNull { it.trim().toLongOrNull() }.maxOrNull() ?: 0L
        return (max / 1000L).toInt()
    }

    private fun readTemp(): Float {
        val cpuScript = "for z in /sys/class/thermal/thermal_zone*; do " +
                "case \"\$(cat \$z/type)\" in *cpu*) cat \$z/temp; break;; esac; done"
        val cpuRaw = ShizukuShell.out(cpuScript).trim().toFloatOrNull()
        if (cpuRaw != null && cpuRaw > 0f) {
            return if (cpuRaw > 1000f) cpuRaw / 1000f else cpuRaw
        }
        val bat = ShizukuShell.out("dumpsys battery | grep temperature")
        val v = Regex("(\\d+)").find(bat)?.groupValues?.get(1)?.toFloatOrNull()
        return if (v != null) v / 10f else 0f
    }

    private fun readRamPct(): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        if (mi.totalMem <= 0L) return 0
        return (100L - (mi.availMem * 100L / mi.totalMem)).toInt()
    }

    private fun readFps(pkg: String): Int {
        val layers = ShizukuShell.out("dumpsys SurfaceFlinger --list").lines().map { it.trim() }
        val layer = layers.firstOrNull { it.contains(pkg) && it.contains("SurfaceView") }
            ?: layers.firstOrNull { it.contains(pkg) }
            ?: return -1
        val out = ShizukuShell.out("dumpsys SurfaceFlinger --latency '" + layer + "'")
        val stamps = out.lines().drop(1).mapNotNull { line ->
            val p = line.trim().split(Regex("\\s+"))
            if (p.size >= 3) p[1].toLongOrNull() else null
        }.filter { it > 0L && it != Long.MAX_VALUE }
        if (stamps.size < 2) return -1
        val last = stamps.maxOrNull() ?: return -1
        return stamps.count { it > last - 1_000_000_000L }
    }

    private fun autoProfile(pkg: String) {
        if (pkg.isEmpty()) return
        val settings = context.getSharedPreferences("settings_prefs", Context.MODE_PRIVATE)
        if (!settings.getBoolean("auto_profile", true)) return
        val boosted = context.getSharedPreferences("game_turbo_prefs", Context.MODE_PRIVATE)
            .getStringSet("boosted_apps", emptySet()) ?: emptySet()
        if (pkg in boosted && pkg != activeGame && GameProfiles.hasProfile(context, pkg)) {
            val profile = GameProfiles.load(context, pkg).copy(compile = false)
            GameProfiles.apply(context, pkg, profile)
            activeGame = pkg
        } else if (activeGame.isNotEmpty() && pkg != activeGame && pkg !in boosted &&
            pkg != context.packageName && pkg != "com.android.systemui"
        ) {
            GameProfiles.restore(context)
            activeGame = ""
        }
    }

    private fun appendLog(t: Telemetry) {
        val dir = context.getExternalFilesDir(null) ?: return
        val file = File(dir, "redmagic_log.txt")
        if (file.exists() && file.length() > 1_000_000L) file.delete()
        val fpsTxt = if (t.fps >= 0) t.fps.toString() else "--"
        val temp = String.format(Locale.US, "%.1f", t.tempC)
        val line = dateFmt.format(Date()) + " | " + (if (t.pkg.isEmpty()) "-" else t.pkg) +
                " | FPS " + fpsTxt + " | CPU " + t.cpuMhz + " MHz | TEMP " + temp +
                " C | RAM " + t.ramUsedPct + "%\n"
        file.appendText(line)
    }
}
