package com.redmagic.boost

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import java.io.BufferedReader
import java.io.File
import java.io.FileWriter
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class LogMonitor(
    private val context: Context,
    private val onStatsUpdated: ((ghz: Double, fps: Int) -> Unit)? = null
) {

    private val isMonitoring = AtomicBoolean(false)
    private var monitorThread: Thread? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var latestGhz: Double = 0.0

    @Volatile
    private var latestFps: Int = 0

    private var frameCount = 0
    private var lastFpsSampleTimeMs = System.currentTimeMillis()
    private var choreographerRunning = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!choreographerRunning) return
            frameCount++
            val now = System.currentTimeMillis()
            val elapsed = now - lastFpsSampleTimeMs
            if (elapsed >= 1000) {
                val calculated = ((frameCount * 1000.0) / elapsed).toInt().coerceIn(0, 240)
                if (calculated > 0) {
                    latestFps = calculated
                }
                frameCount = 0
                lastFpsSampleTimeMs = now
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun start() {
        if (isMonitoring.getAndSet(true)) return
        startChoreographer()

        val logFile = File(context.getExternalFilesDir(null), "redmagic_log.txt")

        monitorThread = Thread {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            while (isMonitoring.get()) {
                val ghz = readCpuFrequencyGhz()
                val sfFps = readSurfaceFlingerFps()
                val fps = sfFps ?: latestFps

                latestGhz = ghz
                latestFps = fps

                val timestamp = sdf.format(Date())
                val line = "[$timestamp] CPU: ${String.format(Locale.US, "%.2f", ghz)} GHz | FPS: $fps\n"

                try {
                    FileWriter(logFile, true).use { writer ->
                        writer.append(line)
                    }
                } catch (_: Exception) {
                }

                mainHandler.post {
                    onStatsUpdated?.invoke(ghz, fps)
                }

                try {
                    Thread.sleep(2000)
                } catch (_: InterruptedException) {
                    break
                }
            }
        }.apply {
            name = "RedMagic-LogMonitor"
            isDaemon = true
            start()
        }
    }

    fun stop() {
        isMonitoring.set(false)
        choreographerRunning = false
        mainHandler.post {
            Choreographer.getInstance().removeFrameCallback(frameCallback)
        }
        monitorThread?.interrupt()
        monitorThread = null
    }

    private fun startChoreographer() {
        mainHandler.post {
            if (!choreographerRunning) {
                choreographerRunning = true
                lastFpsSampleTimeMs = System.currentTimeMillis()
                frameCount = 0
                Choreographer.getInstance().postFrameCallback(frameCallback)
            }
        }
    }

    private fun readCpuFrequencyGhz(): Double {
        if (!ShizukuHelper.hasPermission()) return 0.0
        return try {
            val clazz = Class.forName("rikka.shizuku.Shizuku")
            val method = clazz.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val cmd = "cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq 2>/dev/null"
            val process = method.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            var maxKhz = 0L
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val freq = line?.trim()?.toLongOrNull() ?: 0L
                if (freq > maxKhz) maxKhz = freq
            }
            process.waitFor()
            maxKhz / 1_000_000.0
        } catch (_: Exception) {
            0.0
        }
    }

    private fun readSurfaceFlingerFps(): Int? {
        if (!ShizukuHelper.hasPermission()) return null
        return try {
            val clazz = Class.forName("rikka.shizuku.Shizuku")
            val method = clazz.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val cmd = "dumpsys SurfaceFlinger --latency 2>/dev/null | head -n 20"
            val process = method.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val timestamps = mutableListOf<Long>()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val parts = line?.trim()?.split(Regex("\\s+")) ?: continue
                if (parts.size >= 2) {
                    val presentNano = parts[1].toLongOrNull()
                    if (presentNano != null && presentNano > 0L) {
                        timestamps.add(presentNano)
                    }
                }
            }
            process.waitFor()
            if (timestamps.size >= 2) {
                val minTs = timestamps.minOrNull()!!
                val maxTs = timestamps.maxOrNull()!!
                val deltaNs = maxTs - minTs
                if (deltaNs > 0L) {
                    val fps = ((timestamps.size - 1) * 1_000_000_000.0 / deltaNs).toInt()
                    return fps.coerceIn(1, 240)
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }
}
