package com.redmagic.boost
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import rikka.shizuku.Shizuku
class MainActivity : AppCompatActivity() {
    private val REQUEST_CODE = 100
    private lateinit var viewPager: ViewPager2
    private var isDevilActive = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        viewPager = findViewById(R.id.viewPager)
        viewPager.adapter = PageAdapter()
        Shizuku.addRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == REQUEST_CODE) recreate()
        }
    }
    inner class PageAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = 2
        override fun getItemViewType(position: Int) = position
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val layout = if (viewType == 0) R.layout.page_turbo else R.layout.page_devil
            val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
            return object : RecyclerView.ViewHolder(view) {}
        }
        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            if (position == 0) {
                val tvStatus = holder.itemView.findViewById<TextView>(R.id.tvStatus)
                val btnConnect = holder.itemView.findViewById<Button>(R.id.btnConnect)
                val btnTurbo = holder.itemView.findViewById<Button>(R.id.btnTurbo)
                if (ShizukuHelper.hasPermission()) {
                    tvStatus.text = "Estado: ✅ Shizuku Conectado"
                    tvStatus.setTextColor(getColor(R.color.cyan_magic))
                } else {
                    tvStatus.text = "Estado: ⚠️ Falta permiso de Shizuku"
                    tvStatus.setTextColor(getColor(R.color.red_magic))
                }
                btnConnect.setOnClickListener {
                    if (ShizukuHelper.hasPermission()) Toast.makeText(this@MainActivity, "Ya conectado", Toast.LENGTH_SHORT).show()
                    else { try { Shizuku.requestPermission(REQUEST_CODE) } catch (e: Exception) { Toast.makeText(this@MainActivity, "Abre Shizuku", Toast.LENGTH_LONG).show() } }
                }
                btnTurbo.setOnClickListener {
                    if (!ShizukuHelper.hasPermission()) { Toast.makeText(this@MainActivity, "Conecta Shizuku", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                    ShizukuHelper.runCommand("settings put global zen_mode 1")
                    ShizukuHelper.runCommand("settings put system screen_off_timeout 2147483647")
                    ShizukuHelper.runCommand("am kill-all")
                    ShizukuHelper.runCommand("pm trim-caches 999G")
                    Toast.makeText(this@MainActivity, "¡Turbo Aplicado!", Toast.LENGTH_LONG).show()
                }
            } else {
                val btnDevil = holder.itemView.findViewById<Button>(R.id.btnDevil)
                btnDevil.text = if (isDevilActive) "DETENER BUCLE" else "ACTIVAR BUCLE\nEXTREMO"
                btnDevil.setBackgroundColor(if (isDevilActive) getColor(R.color.red_magic) else getColor(R.color.cyan_magic))
                btnDevil.setTextColor(if (isDevilActive) getColor(R.color.text_white) else getColor(R.color.bg_dark))
                btnDevil.setOnClickListener {
                    if (!ShizukuHelper.hasPermission()) { Toast.makeText(this@MainActivity, "Conecta Shizuku", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                    if (!isDevilActive) { startForegroundService(Intent(this@MainActivity, DevilService::class.java)); isDevilActive = true; Toast.makeText(this@MainActivity, "¡MODO DIABLO! 🔥", Toast.LENGTH_LONG).show() }
                    else { stopService(Intent(this@MainActivity, DevilService::class.java)); isDevilActive = false; Toast.makeText(this@MainActivity, "Modo Diablo off", Toast.LENGTH_SHORT).show() }
                    notifyItemChanged(1)
                }
            }
        }
    }
}
