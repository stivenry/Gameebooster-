package com.redmagic.boost

/**
 * Complemento de ShizukuHelper: igual que runCommand pero devuelve la salida
 * estandar del comando (necesaria para la telemetria y para listar paquetes).
 */
object ShizukuShell {

    data class Result(val ok: Boolean, val out: String)

    fun run(command: String): Result {
        if (!ShizukuHelper.hasPermission()) return Result(false, "")
        return try {
            val clazz = Class.forName("rikka.shizuku.Shizuku")
            val method = clazz.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(
                null,
                arrayOf("sh", "-c", "(" + command + ") 2>/dev/null"),
                null,
                null
            ) as Process
            val text = process.inputStream.bufferedReader().use { it.readText() }
            val code = process.waitFor()
            Result(code == 0, text.trim())
        } catch (e: Exception) {
            Result(false, "")
        }
    }

    fun out(command: String): String = run(command).out
}
