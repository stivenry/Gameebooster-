package com.redmagic.boost

import android.app.ActivityManager
import android.content.Context

object TurboActions {

    fun ramFreeMb(ctx: Context): Long {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.availMem / (1024L * 1024L)
    }

    /** Bloqueante: llamar desde un hilo secundario. */
    fun boost(ctx: Context): List<String> {
        val lines = mutableListOf<String>()
        if (!ShizukuHelper.hasPermission()) {
            lines.add("• Conecta Shizuku para limpiar cache y procesos")
            return lines
        }
        val before = ramFreeMb(ctx)
        val trimOk = ShizukuHelper.runCommand("pm trim-caches 999999999999")
        val killOk = ShizukuHelper.runCommand("am kill-all")
        lines.add(if (trimOk) "• Cache del sistema purgada" else "• No se pudo purgar la cache")
        lines.add(if (killOk) "• Procesos en segundo plano detenidos" else "• No se pudieron detener procesos")
        try {
            Thread.sleep(900)
        } catch (e: InterruptedException) {
            // ignorado
        }
        val after = ramFreeMb(ctx)
        lines.add("• RAM libre: " + before + " MB -> " + after + " MB")
        return lines
    }
}
