package com.redmagic.boost.ui

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.materialswitch.MaterialSwitch
import com.redmagic.boost.DevilService
import com.redmagic.boost.R
import com.redmagic.boost.ShizukuHelper
import com.redmagic.boost.Tweak
import com.redmagic.boost.TweakCatalog

class SettingsFragment : Fragment() {

    private var suppress = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val switchDevil = view.findViewById<MaterialSwitch>(R.id.switch_devil_mode)
        val tvDevilStatus = view.findViewById<TextView>(R.id.tv_devil_status)
        val tvVersion = view.findViewById<TextView>(R.id.tv_app_version)
        val switchAuto = view.findViewById<MaterialSwitch>(R.id.switch_auto_profile)
        val container = view.findViewById<LinearLayout>(R.id.ll_tweaks)

        tvVersion.text = "RedMagicBoost v5.0 (Build 5)"

        val prefs = requireContext().getSharedPreferences("settings_prefs", Context.MODE_PRIVATE)
        val isDevilActive = prefs.getBoolean("devil_mode_enabled", false)
        switchDevil.isChecked = isDevilActive
        updateStatusText(tvDevilStatus, isDevilActive)

        switchDevil.setOnCheckedChangeListener { _, isChecked ->
            if (suppress) return@setOnCheckedChangeListener
            if (isChecked) {
                if (!ShizukuHelper.hasPermission()) {
                    revert(switchDevil, false)
                    Toast.makeText(requireContext(), "Requiere conexion con Shizuku", Toast.LENGTH_SHORT).show()
                    return@setOnCheckedChangeListener
                }
                val intent = Intent(requireContext(), DevilService::class.java)
                ContextCompat.startForegroundService(requireContext(), intent)
                prefs.edit().putBoolean("devil_mode_enabled", true).apply()
                updateStatusText(tvDevilStatus, true)
                Toast.makeText(requireContext(), "Modo Diablo activado (2.2GHz)", Toast.LENGTH_SHORT).show()
            } else {
                requireContext().stopService(Intent(requireContext(), DevilService::class.java))
                prefs.edit().putBoolean("devil_mode_enabled", false).apply()
                updateStatusText(tvDevilStatus, false)
                Toast.makeText(requireContext(), "Modo Diablo desactivado", Toast.LENGTH_SHORT).show()
            }
        }

        switchAuto.isChecked = prefs.getBoolean("auto_profile", true)
        switchAuto.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("auto_profile", isChecked).apply()
        }

        // Catalogo de ajustes agrupados por herramienta de origen
        val tweakPrefs = requireContext().getSharedPreferences("tweaks_prefs", Context.MODE_PRIVATE)
        val groups = TweakCatalog.all.groupBy { it.group }
        for ((groupName, list) in groups) {
            addHeader(container, groupName)
            for (t in list) {
                addTweakRow(container, t, tweakPrefs)
            }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun addHeader(parent: LinearLayout, text: String) {
        val tv = TextView(requireContext())
        tv.text = text
        tv.setTextColor(ContextCompat.getColor(requireContext(), R.color.accent_blue))
        tv.textSize = 14f
        tv.setTypeface(null, Typeface.BOLD)
        tv.setPadding(0, dp(20), 0, dp(6))
        parent.addView(tv)
    }

    private fun addTweakRow(parent: LinearLayout, t: Tweak, tweakPrefs: android.content.SharedPreferences) {
        val ctx = requireContext()
        val appCtx = ctx.applicationContext
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.VERTICAL
        row.setBackgroundColor(ContextCompat.getColor(ctx, R.color.surface_card))
        row.setPadding(dp(14), dp(10), dp(14), dp(10))
        val rowLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        rowLp.bottomMargin = dp(8)
        row.layoutParams = rowLp

        val sw = MaterialSwitch(ctx)
        sw.text = t.title
        sw.setTextColor(ContextCompat.getColor(ctx, R.color.text_primary))
        sw.textSize = 14f
        sw.isChecked = tweakPrefs.getBoolean(t.key, false)

        val desc = TextView(ctx)
        desc.text = t.desc
        desc.setTextColor(ContextCompat.getColor(ctx, R.color.text_secondary))
        desc.textSize = 12f

        sw.setOnCheckedChangeListener { _, checked ->
            if (suppress) return@setOnCheckedChangeListener
            if (!ShizukuHelper.hasPermission()) {
                revert(sw, !checked)
                Toast.makeText(appCtx, "Requiere conexion con Shizuku", Toast.LENGTH_SHORT).show()
                return@setOnCheckedChangeListener
            }
            Thread {
                val ok = if (checked) t.enable(appCtx) else t.disable(appCtx)
                activity?.runOnUiThread {
                    if (ok) {
                        tweakPrefs.edit().putBoolean(t.key, checked).apply()
                        Toast.makeText(
                            appCtx,
                            t.title + (if (checked) ": activado" else ": desactivado"),
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        revert(sw, !checked)
                        Toast.makeText(appCtx, t.title + ": no soportado en tu ROM/sin root", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }

        row.addView(sw)
        row.addView(desc)
        parent.addView(row)
    }

    private fun revert(sw: MaterialSwitch, value: Boolean) {
        suppress = true
        sw.isChecked = value
        suppress = false
    }

    private fun updateStatusText(textView: TextView, active: Boolean) {
        if (active) {
            textView.text = "Bucle 2.2GHz: ACTIVO"
            textView.setTextColor(ContextCompat.getColor(requireContext(), R.color.accent_red))
        } else {
            textView.text = "Bucle 2.2GHz: INACTIVO"
            textView.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary))
        }
    }
}
