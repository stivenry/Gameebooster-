package com.redmagic.boost.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.redmagic.boost.DevilService
import com.redmagic.boost.MainActivity
import com.redmagic.boost.OverlayService
import com.redmagic.boost.R
import com.redmagic.boost.ShizukuHelper
import java.io.File

class SettingsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvShizuku = view.findViewById<TextView>(R.id.tvShizukuStatus)
        val tvLogPath = view.findViewById<TextView>(R.id.tvLogFilePath)

        val hasShizuku = ShizukuHelper.hasPermission()
        tvShizuku.text = if (hasShizuku) "Shizuku: Permiso concedido" else "Shizuku: Sin permiso o inactivo"

        val logFile = File(requireContext().getExternalFilesDir(null), "redmagic_log.txt")
        tvLogPath.text = "Log: ${logFile.absolutePath}"

        view.findViewById<Button>(R.id.btnSettingsOverlayPerm).setOnClickListener {
            (activity as? MainActivity)?.requestOverlayPermission()
        }

        view.findViewById<Button>(R.id.btnSettingsStoragePerm).setOnClickListener {
            (activity as? MainActivity)?.requestStoragePermission()
        }

        view.findViewById<Button>(R.id.btnStopServices).setOnClickListener {
            val ctx = requireContext()
            ctx.stopService(Intent(ctx, OverlayService::class.java))
            ctx.stopService(Intent(ctx, DevilService::class.java))
            Toast.makeText(ctx, "Servicios detenidos", Toast.LENGTH_SHORT).show()
        }
    }
}
