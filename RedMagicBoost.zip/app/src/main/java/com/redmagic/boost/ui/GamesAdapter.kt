package com.redmagic.boost.ui

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.redmagic.boost.R

data class GameItem(
    val name: String,
    val packageName: String,
    val icon: Drawable
)

class GamesAdapter(
    private val items: List<GameItem>,
    private val onLaunchClick: (GameItem) -> Unit
) : RecyclerView.Adapter<GamesAdapter.GameViewHolder>() {

    class GameViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val ivIcon: ImageView = view.findViewById(R.id.ivGameIcon)
        val tvName: TextView = view.findViewById(R.id.tvGameName)
        val tvPkg: TextView = view.findViewById(R.id.tvGamePackage)
        val btnLaunch: Button = view.findViewById(R.id.btnLaunchGame)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GameViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_game, parent, false)
        return GameViewHolder(view)
    }

    override fun onBindViewHolder(holder: GameViewHolder, position: Int) {
        val item = items[position]
        holder.ivIcon.setImageDrawable(item.icon)
        holder.tvName.text = item.name
        holder.tvPkg.text = item.packageName
        holder.btnLaunch.setOnClickListener { onLaunchClick(item) }
    }

    override fun getItemCount(): Int = items.size
}
