package com.redmagic.boost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class DevilService : Service() {

    private var isRunning = false
    private var workerThread: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notification: Notification = NotificationCompat.Builder(this, "devil_mode_channel")
            .setContentTitle("RedMagicBoost - Modo Diablo")
            .setContentText("Manteniendo frecuencia minima de CPU en 2.2GHz")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setOngoing(true)
            .build()

        startForeground(101, notification)

        if (!isRunning) {
            isRunning = true
            workerThread = Thread {
                ShizukuHelper.runCommand("cmd power set-fixed-performance-mode-enabled true")
                val cmd = "for i in 0 1 2 3 4 5 6 7; do echo 2200000 > /sys/devices/system/cpu/cpu\$i/cpufreq/scaling_min_freq 2>/dev/null; done"
                while (isRunning) {
                    ShizukuHelper.runCommand(cmd)
                    try {
                        Thread.sleep(2000)
                    } catch (e: InterruptedException) {
                        break
                    }
                }
            }.apply { start() }
        }

        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        workerThread?.interrupt()
        Thread {
            ShizukuHelper.runCommand("cmd power set-fixed-performance-mode-enabled false")
        }.start()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "devil_mode_channel",
                "Modo Diablo Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
