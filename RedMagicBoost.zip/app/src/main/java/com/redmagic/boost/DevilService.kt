package com.redmagic.boost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.util.concurrent.atomic.AtomicBoolean

class DevilService : Service() {

    private val isRunning = AtomicBoolean(false)
    private var workerThread: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        isRunning.set(true)
        startDevilLoop()
    }

    private fun startForegroundNotification() {
        val channelId = "redmagic_devil_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "RedMagic Modo Diablo",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Modo Diablo Activo (2.2 GHz)")
            .setContentText("Manteniendo frecuencia de CPU en 2200000 KHz")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .build()

        startForeground(102, notification)
    }

    private fun startDevilLoop() {
        workerThread = Thread {
            val targetFreqKhz = 2200000
            val cmd = "for cpu in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do " +
                "[ -w "\$cpu/scaling_min_freq" ] && echo $targetFreqKhz > "\$cpu/scaling_min_freq"; " +
                "[ -w "\$cpu/scaling_max_freq" ] && echo $targetFreqKhz > "\$cpu/scaling_max_freq"; " +
                "done"
            while (isRunning.get()) {
                ShizukuHelper.runCommand(cmd)
                try {
                    Thread.sleep(2000)
                } catch (_: InterruptedException) {
                    break
                }
            }
        }.apply {
            name = "DevilMode-2.2GHz-Thread"
            isDaemon = true
            start()
        }
    }

    override fun onDestroy() {
        isRunning.set(false)
        workerThread?.interrupt()
        super.onDestroy()
    }
}
