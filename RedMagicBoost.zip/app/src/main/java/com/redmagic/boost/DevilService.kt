package com.redmagic.boost
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import kotlinx.coroutines.*
class DevilService : Service() {
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var loopJob: Job? = null
    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel("devil_channel", "Modo Diablo", NotificationManager.IMPORTANCE_LOW)
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
        val notification = android.app.Notification.Builder(this, "devil_channel")
            .setContentTitle("Modo Diablo Activado").setContentText("Forzando CPU...").setSmallIcon(android.R.drawable.ic_menu_compass).build()
        startForeground(1, notification)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        loopJob?.cancel()
        loopJob = serviceScope.launch {
            while (isActive) {
                for (i in 0..7) {
                    ShizukuHelper.runCommand("echo performance > /sys/devices/system/cpu/cpu$i/cpufreq/scaling_governor")
                    ShizukuHelper.runCommand("echo 2200000 > /sys/devices/system/cpu/cpu$i/cpufreq/scaling_max_freq")
                    ShizukuHelper.runCommand("echo 2200000 > /sys/devices/system/cpu/cpu$i/cpufreq/scaling_min_freq")
                }
                delay(5000) 
            }
        }
        return START_STICKY
    }
    override fun onDestroy() {
        loopJob?.cancel()
        for (i in 0..7) { ShizukuHelper.runCommand("echo schedutil > /sys/devices/system/cpu/cpu$i/cpufreq/scaling_governor") }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
