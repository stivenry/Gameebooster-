package com.redmagic.boost.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.redmagic.boost.DevilService
import com.redmagic.boost.LogMonitor
import com.redmagic.boost.MainActivity
import com.redmagic.boost.OverlayService
import com.redmagic.boost.R
import com.redmagic.boost.ShizukuHelper
import java.util.Locale

class TurboFragment : Fragment() {

    private var logMonitor: LogMonitor? = null
    private var tvGhz: TextView? = null
    private var tvFps: TextView? = null
    private var tvLogStatus: TextView? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_turbo, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tvGhz = view.findViewById(R.id.tvCurrentGhz)
        tvFps = view.findViewById(R.id.tvCurrentFps)
        tvLogStatus = view.findViewById(R.id.tvLogStatus)

        view.findViewById<Button>(R.id.btnToggleOverlay).setOnClickListener {
            val ctx = requireContext()
            if (!Settings.canDrawOverlays(ctx)) {
                (activity as? MainActivity)?.requestOverlayPermission()
                Toast.makeText(ctx, "Concede primero el permiso de superposición", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val intent = Intent(ctx, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(intent)
            } else {
                ctx.startService(intent)
            }
            Toast.makeText(ctx, "Menú flotante activado", Toast.LENGTH_SHORT).show()
        }

        view.findViewById<Button>(R.id.btnRunKillAll).setOnClickListener {
            Thread {
                val ok = ShizukuHelper.runCommand("am kill-all")
                activity?.runOnUiThread {
                    val msg = if (ok) "Procesos en segundo plano limpiados" else "Sin permiso de Shizuku"
                    Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                }
            }.start()
        }

        view.findViewById<Button>(R.id.btnToggleDevil).setOnClickListener {
            val ctx = requireContext()
            val intent = Intent(ctx, DevilService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(intent)
            } else {
                ctx.startService(intent)
            }
            Toast.makeText(ctx, "Modo Diablo (2.2 GHz) iniciado", Toast.LENGTH_SHORT).show()
        }

        view.findViewById<Button>(R.id.btnStartLog).setOnClickListener {
            if (logMonitor == null) {
                logMonitor = LogMonitor(requireContext()) { ghz, fps ->
                    tvGhz?.text = String.format(Locale.US, "%.2f GHz", ghz)
                    tvFps?.text = "$fps FPS"
                    tvLogStatus?.text = "Registrando en redmagic_log.txt"
                }
                logMonitor?.start()
                Toast.makeText(requireContext(), "Registro iniciado", Toast.LENGTH_SHORT).show()
            } else {
                logMonitor?.stop()
                logMonitor = null
                tvLogStatus?.text = "Registro detenido"
                Toast.makeText(requireContext(), "Registro detenido", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        logMonitor?.stop()
        logMonitor = null
        tvGhz = null
        tvFps = null
        tvLogStatus = null
        super.onDestroyView()
    }
}
