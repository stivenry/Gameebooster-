package com.redmagic.boost.ui

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButton
import com.redmagic.boost.OverlayService
import com.redmagic.boost.R
import com.redmagic.boost.ShizukuHelper
import com.redmagic.boost.TurboActions
import rikka.shizuku.Shizuku

class TurboFragment : Fragment() {

    private lateinit var tvShizukuStatus: TextView
    private lateinit var tvBoostLog: TextView
    private lateinit var btnConnectShizuku: MaterialButton
    private lateinit var btnTurboBoost: MaterialButton
    private lateinit var btnOverlay: MaterialButton

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == 1001) {
            activity?.runOnUiThread {
                updateShizukuStatus()
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(requireContext(), "Shizuku conectado", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_turbo, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tvShizukuStatus = view.findViewById(R.id.tv_shizuku_status)
        tvBoostLog = view.findViewById(R.id.tv_boost_log)
        btnConnectShizuku = view.findViewById(R.id.btn_connect_shizuku)
        btnTurboBoost = view.findViewById(R.id.btn_turbo_boost)
        btnOverlay = view.findViewById(R.id.btn_overlay)

        Shizuku.addRequestPermissionResultListener(permissionListener)
        updateShizukuStatus()

        btnConnectShizuku.setOnClickListener { requestShizukuPermission() }
        btnTurboBoost.setOnClickListener { executeTurboBoost() }
        btnOverlay.setOnClickListener { toggleOverlay() }
    }

    override fun onResume() {
        super.onResume()
        updateShizukuStatus()
        updateOverlayButton()
    }

    private fun updateShizukuStatus() {
        val connected = ShizukuHelper.hasPermission()
        if (connected) {
            tvShizukuStatus.text = "Estado Shizuku: Conectado"
            tvShizukuStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.accent_blue))
        } else {
            tvShizukuStatus.text = "Estado Shizuku: Desconectado"
            tvShizukuStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.accent_red))
        }
    }

    private fun requestShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                Toast.makeText(requireContext(), "Inicia el servicio de Shizuku primero", Toast.LENGTH_SHORT).show()
                return
            }
            if (ShizukuHelper.hasPermission()) {
                Toast.makeText(requireContext(), "Permiso ya concedido", Toast.LENGTH_SHORT).show()
            } else {
                Shizuku.requestPermission(1001)
            }
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Shizuku no esta instalado o activo", Toast.LENGTH_SHORT).show()
        }
    }

    private fun executeTurboBoost() {
        tvBoostLog.text = "Optimizando..."
        val ctx = requireContext().applicationContext
        Thread {
            val lines = TurboActions.boost(ctx)
            activity?.runOnUiThread { tvBoostLog.text = lines.joinToString("\n") }
        }.start()
    }

    private fun overlayRunning(): Boolean =
        requireContext().getSharedPreferences("overlay_prefs", Context.MODE_PRIVATE)
            .getBoolean("running", false)

    private fun updateOverlayButton() {
        btnOverlay.text = if (overlayRunning()) "Ocultar menu flotante" else "Mostrar menu flotante"
    }

    private fun toggleOverlay() {
        val ctx = requireContext()
        if (!Settings.canDrawOverlays(ctx)) {
            Toast.makeText(ctx, "Concede el permiso de superposicion", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
            )
            return
        }
        val intent = Intent(ctx, OverlayService::class.java)
        if (overlayRunning()) {
            ctx.stopService(intent)
            btnOverlay.text = "Mostrar menu flotante"
        } else {
            ContextCompat.startForegroundService(ctx, intent)
            btnOverlay.text = "Ocultar menu flotante"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Shizuku.removeRequestPermissionResultListener(permissionListener)
    }
}
