package com.redmagic.boost.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.redmagic.boost.GameProfiles
import com.redmagic.boost.R

/** Ajustes por juego: tactil, bordes, muestreo, resolucion, densidad y modo de juego. */
class GameSettingsFragment : Fragment() {

    private var pkg: String = ""
    private var gameName: String = ""

    private lateinit var sTouch: Slider
    private lateinit var sEdge: Slider
    private lateinit var sRes: Slider
    private lateinit var sDensity: Slider
    private lateinit var swBoost: MaterialSwitch
    private lateinit var swPerf: MaterialSwitch
    private lateinit var swCompile: MaterialSwitch
    private lateinit var tvTouch: TextView
    private lateinit var tvEdge: TextView
    private lateinit var tvRes: TextView
    private lateinit var tvDensity: TextView
    private lateinit var tvLog: TextView

    companion object {
        fun newInstance(pkg: String, name: String): GameSettingsFragment {
            val f = GameSettingsFragment()
            val b = Bundle()
            b.putString("pkg", pkg)
            b.putString("name", name)
            f.arguments = b
            return f
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_game_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        pkg = requireArguments().getString("pkg") ?: ""
        gameName = requireArguments().getString("name") ?: pkg

        view.findViewById<TextView>(R.id.tv_game_title).text = gameName
        view.findViewById<TextView>(R.id.tv_game_pkg).text = pkg
        sTouch = view.findViewById(R.id.slider_touch)
        sEdge = view.findViewById(R.id.slider_edge)
        sRes = view.findViewById(R.id.slider_res)
        sDensity = view.findViewById(R.id.slider_density)
        swBoost = view.findViewById(R.id.switch_touch_boost)
        swPerf = view.findViewById(R.id.switch_perf_mode)
        swCompile = view.findViewById(R.id.switch_compile)
        tvTouch = view.findViewById(R.id.tv_touch_value)
        tvEdge = view.findViewById(R.id.tv_edge_value)
        tvRes = view.findViewById(R.id.tv_res_value)
        tvDensity = view.findViewById(R.id.tv_density_value)
        tvLog = view.findViewById(R.id.tv_apply_log)

        val ctx = requireContext()
        val p = GameProfiles.load(ctx, pkg)

        // Los valores deben caer exactamente en el paso (stepSize) del Slider
        sTouch.value = p.sens.coerceIn(0, 100).toFloat()
        sEdge.value = p.edge.coerceIn(0, 100).toFloat()
        sRes.value = ((p.resPercent.coerceIn(50, 100) / 5) * 5).toFloat()
        val baseDensity = if (p.density > 0) p.density else ctx.resources.displayMetrics.densityDpi
        sDensity.value = (((baseDensity + 5) / 10) * 10).coerceIn(240, 640).toFloat()
        swBoost.isChecked = p.touchBoost
        swPerf.isChecked = p.perfMode
        swCompile.isChecked = p.compile
        refreshLabels()

        sTouch.addOnChangeListener { _, _, _ -> refreshLabels() }
        sEdge.addOnChangeListener { _, _, _ -> refreshLabels() }
        sRes.addOnChangeListener { _, _, _ -> refreshLabels() }
        sDensity.addOnChangeListener { _, _, _ -> refreshLabels() }

        view.findViewById<MaterialButton>(R.id.btn_apply).setOnClickListener { runApply(false) }
        view.findViewById<MaterialButton>(R.id.btn_launch).setOnClickListener { runApply(true) }
        view.findViewById<MaterialButton>(R.id.btn_restore).setOnClickListener { runRestore() }
    }

    private fun refreshLabels() {
        tvTouch.text = "Sensibilidad tactil: " + sTouch.value.toInt() + "%"
        tvEdge.text = "Supresion de bordes: " + sEdge.value.toInt() + "%"
        tvRes.text = "Resolucion: " + sRes.value.toInt() + "%"
        tvDensity.text = "Densidad: " + sDensity.value.toInt() + " dpi"
    }

    private fun collect(): GameProfiles.Profile {
        return GameProfiles.Profile(
            sens = sTouch.value.toInt(),
            edge = sEdge.value.toInt(),
            touchBoost = swBoost.isChecked,
            resPercent = sRes.value.toInt(),
            density = sDensity.value.toInt(),
            perfMode = swPerf.isChecked,
            compile = swCompile.isChecked
        )
    }

    private fun runApply(launch: Boolean) {
        val ctx = requireContext().applicationContext
        val profile = collect()
        GameProfiles.save(ctx, pkg, profile)
        tvLog.text = "Aplicando..."
        Thread {
            val lines = GameProfiles.apply(ctx, pkg, profile)
            activity?.runOnUiThread {
                tvLog.text = lines.joinToString("\n")
                if (launch) {
                    val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
                    if (i != null) {
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        ctx.startActivity(i)
                    }
                }
            }
        }.start()
    }

    private fun runRestore() {
        val ctx = requireContext().applicationContext
        tvLog.text = "Restaurando..."
        Thread {
            val lines = GameProfiles.restore(ctx)
            activity?.runOnUiThread { tvLog.text = lines.joinToString("\n") }
        }.start()
    }
}
