# Reglas ProGuard (vacio: minify desactivado)
-keep class rikka.shizuku.** { *; }
